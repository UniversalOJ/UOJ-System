#ifndef __KTH_H__
#define __KTH_H__

#ifdef __cplusplus
extern "C" {
#endif
	int get_a(int p);
	int get_b(int p);
	int get_c(int p);
	int query_kth(int n_a, int n_b, int n_c, int k);
#ifdef __cplusplus
}
#endif

#endif
